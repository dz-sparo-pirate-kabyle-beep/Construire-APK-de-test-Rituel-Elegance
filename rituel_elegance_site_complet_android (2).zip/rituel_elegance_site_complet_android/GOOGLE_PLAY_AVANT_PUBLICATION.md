# Rituel Élégance — ce qui change dans les déclarations Play Console

**Ne pas valider la déclaration « Sécurité des données » précédente sans audit de ce nouveau projet.**

Cette version charge le site Shopify complet dans une WebView. Les formulaires (client, devis, newsletter), cookies, scripts Shopify, paiement et outils éventuels de mesure peuvent collecter/transmettre des données, même si le code Dart ne les stocke pas.

Les éléments à auditer avec le site final incluent : nom, adresse e-mail, téléphone, adresse postale, historique d'achat, navigation, identifiants/cookies, et informations fournies dans la demande de devis (plaque d'immatriculation, WhatsApp). Les déclarations sur la collecte, le partage et les finalités doivent suivre les faits réels et les rôles des prestataires.

## Achats numériques
- **Livres et PDF visibles dans l'application** : OUI.
- **Achat de contenus numériques possible dans la version finale ?** Répondre **OUI** à Google Play si effectivement proposé, puis mettre en place une méthode de paiement conforme aux règles applicables ; le prototype a bloqué le checkout et nécessite un parcours conforme avant publication.
- Si aucun achat numérique n'est possible, la réponse peut différer, mais elle doit suivre le comportement final, pas l'intention.

## Accès à l'application
- L'application affiche le site complet, y compris les éventuels comptes clients Shopify : réexaminer la réponse à la question de connexion. Prévoir des identifiants de test pour Google si du contenu nécessite une connexion.

## Politique de confidentialité / suppression
- https://rituel-elegance.fr/policies/privacy-policy
- https://rituel-elegance.fr/pages/suppression-de-compte-et-de-donnees-rituel-elegance
- Mettre la politique à jour pour expliciter l'application, la WebView, les commandes, les demandes de devis automobiles, les cookies et les prestataires.

## Pièces auto / demande de devis
- https://rituel-elegance.fr/pages/pieces-automobiles-devis
- Le formulaire mobile crée un brouillon d'e-mail à envoyer manuellement ; la page du site doit être testée séparément pour vérifier un éventuel formulaire HTML et son mode d'envoi.

## Avant l'envoi
1. Tester le fichier AAB signé sur Android.
2. Régler les achats numériques selon Google Play Payments.
3. Vérifier la sécurité des données, les cookies et les tiers du site.
4. Tester l'envoi du devis et toute pièce jointe éventuelle.
5. Remplir correctement les catégories de Google Play, y compris le public à partir de 13 ans.
6. Réaliser le test fermé demandé par votre compte personnel Google Play.

Sources :
- https://support.google.com/googleplay/android-developer/answer/9858738
- https://support.google.com/googleplay/android-developer/answer/10787469
- https://support.google.com/googleplay/android-developer/answer/9898783
