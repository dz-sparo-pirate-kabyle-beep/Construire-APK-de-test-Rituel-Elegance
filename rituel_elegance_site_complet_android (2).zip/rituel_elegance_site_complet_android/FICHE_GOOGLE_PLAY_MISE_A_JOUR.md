# Fiche Google Play — nouvelle version à finaliser après tests

## Nom
Rituel Élégance - Shop de luxe

## Description courte
Mode, cosmétiques, livres numériques et demandes de devis pour pièces auto.

## Description longue
Bienvenue dans l'univers Rituel Élégance ! Retrouvez notre boutique officiel sur Android pour découvrir la mode, les cosmétiques, les accessoires et les livres et guides numériques. L'application donne accès aux collections et aux nouveautés proposées sur rituel-elegance.fr.

MODE, BEAUTÉ ET SHOPPING
Parcourez nos collections de vêtements, chaussures, accessoires, soins capillaires et cosmétiques. Retrouvez les descriptions, les photos, les prix et les variantes proposés sur notre boutique. Le catalogue évolue avec les nouveautés publiées sur le site.

COSMÉTIQUES EN MARQUE BLANCHE — LOTS DE 20
Rituel Élégance propose des cosmétiques en marque blanche, notamment en lots de 20 unités, pour les particuliers comme pour les professionnels. Si vous souhaitez développer votre marque, équiper un institut de beauté ou préparer une commande personnalisée, contactez notre service client avant l'achat afin de vérifier les possibilités, les quantités, les tarifs et les délais.

PERSONNALISATION SUR DEMANDE
Tous les produits de notre site peuvent faire l'objet d'une demande de personnalisation. Avant de commander, contactez le service client avec les références, quantités et détails du projet. Les possibilités et conditions sont confirmées avant toute commande personnalisée.

LIVRES ET GUIDES NUMÉRIQUES
Découvrez également notre collection de livres et de guides au format numérique. Consultez leur présentation et les informations affichées dans la boutique. Les modalités d'achat ou d'accès aux contenus numériques depuis l'application dépendront de la version publiée et des règles Google Play applicables.

PIÈCES AUTOMOBILES — DEMANDE DE DEVIS
Vous recherchez une pièce automobile neuve ou reconditionnée ? Consultez notre page de devis dédiée et préparez une demande avec les renseignements de votre véhicule, la pièce recherchée et vos coordonnées. Un formulaire mobile peut vous aider à préparer un message destiné au service client. Le devis est étudié avant toute proposition de paiement.

UNE BOUTIQUE ACCESSIBLE SUR ANDROID
Retrouvez la navigation de notre site sur votre téléphone : catalogue, collections, livres numériques, devis automobile et contact. L'accès aux contenus nécessite une connexion Internet. Les fonctions disponibles peuvent évoluer selon les options techniques et les conditions de Google Play.

Site officiel : https://www.rituel-elegance.fr

## Remarques avant publication
- Ne pas annoncer un paiement numérique intégré tant qu'il n'est pas conforme et opérationnel.
- Vérifier le formulaire de devis et les captures d'écran réelles de l'application.
- Vérifier les catégories et produits affichés, notamment ceux assujettis à une limite d'âge.
- Actualiser les déclarations « Sécurité des données » pour la version WebView réellement publiée.
