#!/usr/bin/env python3
"""After `flutter create --platforms android .`, align Android release metadata.

Usage:
    python scripts/prepare_android.py --package fr.rituelelegance.boutique
IMPORTANT: Use the EXACT package name displayed in YOUR Google Play Console.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import re
import sys

p = argparse.ArgumentParser()
p.add_argument('--package', required=True, help='Exact Google Play Console package ID')
a = p.parse_args()
if not re.fullmatch(r'[a-zA-Z][\w]*(?:\.[a-zA-Z][\w]*){1,}', a.package):
    sys.exit('Invalid package ID: ' + a.package)
root = Path(__file__).resolve().parents[1]
android = root / 'android'
if not android.exists():
    sys.exit('Android project absent. Run: flutter create --platforms android .')

kts = android / 'app' / 'build.gradle.kts'
groovy = android / 'app' / 'build.gradle'
gradle = kts if kts.exists() else groovy
if not gradle.exists():
    sys.exit('Missing android/app/build.gradle(.kts)')
s = gradle.read_text()
if gradle.suffix == '.kts':
    s, found = re.subn(r'(?m)^\s*applicationId\s*=\s*"[^"]+"', f'        applicationId = "{a.package}"', s, count=1)
    s = re.sub(r'(?m)^\s*minSdk\s*=\s*(?:flutter\.minSdkVersion|\d+)', '        minSdk = 24', s, count=1)
else:
    s, found = re.subn(r'(?m)^\s*applicationId\s+(?:"[^"]+"|\x27[^\x27]+\x27)', f'        applicationId "{a.package}"', s, count=1)
    s = re.sub(r'(?m)^\s*minSdkVersion\s+(?:flutter\.minSdkVersion|\d+)', '        minSdkVersion 24', s, count=1)
if not found:
    sys.exit('Could not safely find applicationId in ' + str(gradle))
gradle.write_text(s)

manifest = android / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
m = manifest.read_text()
if 'android.permission.INTERNET' not in m:
    m = re.sub(r'(<manifest\b[^>]*>)', r'\1\n    <uses-permission android:name="android.permission.INTERNET" />', m, count=1)
m = re.sub(r'android:label="[^"]*"', 'android:label="Rituel Élégance"', m, count=1)
manifest.write_text(m)
print('Android applicationId:', a.package)
print('INTERNET permission and Android app label prepared.')
print('Still required: review manifests, app signing, Play Billing, release testing.')
