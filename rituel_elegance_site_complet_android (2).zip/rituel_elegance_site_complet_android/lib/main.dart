import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Vitrine Android de Rituel Élégance. 
/// ATTENTION : le paiement est neutralisé dans ce prototype de pré-publication.
/// Le parcours d'achat de produits numériques exige une intégration conforme
/// à la politique de paiements Google Play avant mise en production.
const site = 'https://rituel-elegance.fr';
const digitalCollection = '$site/collections/livres-guides-numeriques';
const carQuotePage = '$site/pages/pieces-automobiles-devis';
const customerContact = 'rituel-elegance-officiel@gmail.com';
const gold = Color(0xFFBD9855);
const black = Color(0xFF161412);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RituelElegance());
}

class RituelElegance extends StatelessWidget {
  const RituelElegance({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Rituel Élégance - Shopping',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: gold),
          scaffoldBackgroundColor: Colors.white,
          appBarTheme: const AppBarTheme(backgroundColor: black, foregroundColor: gold),
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: const Color(0xFFFBF9F5),
            indicatorColor: gold.withValues(alpha: 0.20),
          ),
        ),
        home: const HomeScreen(),
      );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final WebViewController _web;
  int _tab = 0;
  int _progress = 0;
  bool _loadError = false;

  @override
  void initState() {
    super.initState();
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (progress) {
          if (mounted) setState(() => _progress = progress);
        },
        onPageStarted: (_) {
          if (mounted) setState(() => _loadError = false);
        },
        onWebResourceError: (error) {
          if (error.isForMainFrame && mounted) {
            setState(() => _loadError = true);
          }
        },
        onNavigationRequest: _navigationRequest,
      ))
      ..loadRequest(Uri.parse(site));
  }

  bool _isPaymentUrl(Uri url) {
    // Security/launch gate: blocking checkout routes is a development safeguard,
    // NOT a complete Play Billing compliance solution (website JS may change).
    final host = url.host.toLowerCase();
    final path = url.path.toLowerCase();
    return path.contains('/checkout') || path.contains('/checkouts') ||
        host == 'checkout.shopify.com' || host == 'pay.shopify.com' ||
        host == 'shop.app' ||
        path.contains('/payments/') || path.contains('/payment/');
  }

  NavigationDecision _navigationRequest(NavigationRequest request) {
    final uri = Uri.tryParse(request.url);
    if (uri == null) return NavigationDecision.prevent;

    // Never allow non-web schemes to load inside the WebView.
    if (uri.scheme == 'mailto' || uri.scheme == 'tel' || uri.scheme == 'whatsapp') {
      _launchExternal(uri);
      return NavigationDecision.prevent;
    }
    if (uri.scheme != 'https') return NavigationDecision.prevent;

    // Do not activate production checkout for mixed digital/physical goods
    // until the payment flow is explicitly implemented and audited.
    if (_isPaymentUrl(uri)) {
      _message('Version de test : paiement indisponible. Le parcours Google Play doit être validé.');
      return NavigationDecision.prevent;
    }

    final host = uri.host.toLowerCase();
    final isOwnSite = host == 'rituel-elegance.fr' ||
        host == 'www.rituel-elegance.fr' ||
        host == 'rituel-elegance.myshopify.com';
    if (isOwnSite) return NavigationDecision.navigate;

    // E.g. an external informational or download link; external apps/sites
    // must not be used to bypass in-app digital purchase policies.
    _launchExternal(uri);
    return NavigationDecision.prevent;
  }

  Future<void> _launchExternal(Uri uri) async {
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        _message('Impossible d’ouvrir ce lien.');
      }
    } catch (_) {
      _message('Le lien n’a pas pu être ouvert.');
    }
  }

  void _message(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _selectTab(int next) {
    setState(() => _tab = next);
    final target = switch (next) {
      0 => site,
      1 => digitalCollection,
      2 => carQuotePage,
      _ => '$site/pages/contact',
    };
    _web.loadRequest(Uri.parse(target));
  }

  Future<void> _goBack() async {
    if (await _web.canGoBack()) {
      await _web.goBack();
    } else {
      await SystemNavigator.pop();
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) _goBack();
        },
        child: Scaffold(
          appBar: AppBar(
            titleSpacing: 10,
            title: const Text('RITUEL ÉLÉGANCE',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
            actions: [
              IconButton(
                tooltip: 'Retour',
                icon: const Icon(Icons.arrow_back),
                onPressed: _goBack,
              ),
              IconButton(
                tooltip: 'Actualiser',
                icon: const Icon(Icons.refresh),
                onPressed: () => _web.reload(),
              ),
              PopupMenuButton<String>(
                tooltip: 'Informations',
                onSelected: (value) => _web.loadRequest(Uri.parse('$site$value')),
                itemBuilder: (context) => const [
                  PopupMenuItem(value: '/policies/privacy-policy', child: Text('Confidentialité')),
                  PopupMenuItem(
                    value: '/pages/suppression-de-compte-et-de-donnees-rituel-elegance',
                    child: Text('Supprimer mon compte'),
                  ),
                ],
              ),
            ],
          ),
          body: SafeArea(
            child: Column(children: [
              // Visible reminder: this is a development/closed-test build.
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                color: const Color(0xFFFFF3DA),
                child: const Text(
                  'VERSION DE TEST — paiement désactivé avant validation Google Play',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
                ),
              ),
              if (_progress < 100) LinearProgressIndicator(value: _progress / 100),
              Expanded(
                child: Stack(children: [
                  WebViewWidget(controller: _web),
                  if (_loadError)
                    Align(
                      alignment: Alignment.topCenter,
                      child: MaterialBanner(
                        content: const Text('Connexion impossible. Vérifiez Internet puis réessayez.'),
                        actions: [
                          TextButton(onPressed: () => _web.reload(), child: const Text('Réessayer')),
                        ],
                      ),
                    ),
                ]),
              ),
            ]),
          ),
          floatingActionButton: _tab == 2
              ? FloatingActionButton.extended(
                  backgroundColor: black,
                  foregroundColor: gold,
                  icon: const Icon(Icons.description_outlined),
                  label: const Text('Remplir le devis'),
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const CarQuoteForm()),
                  ),
                )
              : null,
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: _selectTab,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.storefront_outlined), label: 'Boutique'),
              NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Numérique'),
              NavigationDestination(icon: Icon(Icons.directions_car_outlined), label: 'Devis auto'),
              NavigationDestination(icon: Icon(Icons.support_agent_outlined), label: 'Contact'),
            ],
          ),
        ),
      );
}

/// Formulaire alternatif autonome correspondant aux informations demandées
/// par la page publique de devis. L'utilisateur doit confirmer l'envoi dans
/// sa messagerie : aucune collecte directe ni transmission automatisée ici.
class CarQuoteForm extends StatefulWidget {
  const CarQuoteForm({super.key});

  @override
  State<CarQuoteForm> createState() => _CarQuoteFormState();
}

class _CarQuoteFormState extends State<CarQuoteForm> {
  final _form = GlobalKey<FormState>();
  final _plate = TextEditingController();
  final _part = TextEditingController();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _address = TextEditingController();
  final _phone = TextEditingController();
  final _whatsApp = TextEditingController();

  @override
  void dispose() {
    for (final c in [_plate, _part, _name, _email, _address, _phone, _whatsApp]) {
      c.dispose();
    }
    super.dispose();
  }

  Widget _field(String label, TextEditingController controller,
      {int lines = 1, TextInputType? keyboard, bool required = true}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboard,
        maxLines: lines,
        textInputAction: lines > 1 ? TextInputAction.newline : TextInputAction.next,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
        validator: (text) => required && (text == null || text.trim().isEmpty)
            ? 'Ce champ est obligatoire'
            : null,
      ),
    );
  }

  String _emailBody() => '''DEMANDE DE DEVIS PIÈCES AUTOMOBILES — RITUEL ÉLÉGANCE

Immatriculation : ${_plate.text.trim()}
Description de la pièce : ${_part.text.trim()}
Nom et prénom : ${_name.text.trim()}
E-mail : ${_email.text.trim()}
Adresse de livraison et pays : ${_address.text.trim()}
Téléphone : ${_phone.text.trim()}
WhatsApp : ${_whatsApp.text.trim()}

Merci de me transmettre un devis avec disponibilité et frais de livraison.
''';

  Future<void> _sendRequest() async {
    if (!_form.currentState!.validate()) return;
    final content = _emailBody();
    final uri = Uri(
      scheme: 'mailto',
      path: customerContact,
      query: 'subject=${Uri.encodeComponent('Demande de devis pièces auto — Rituel Élégance')}'
          '&body=${Uri.encodeComponent(content)}',
    );
    try {
      if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    } catch (_) {
      // Fall back to explicit copy to clipboard, not silent background sending.
    }
    await Clipboard.setData(ClipboardData(text: content));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Aucune messagerie trouvée. La demande a été copiée. Envoyez-la au service client.'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Devis de pièces automobiles')),
        body: SafeArea(
          child: Form(
            key: _form,
            child: ListView(padding: const EdgeInsets.all(18), children: [
              const Text('Décrivez la pièce recherchée',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 9),
              const Text(
                'Ce formulaire ouvre votre application e-mail avec une demande préremplie. '
                'Vérifiez les informations puis appuyez sur Envoyer dans votre messagerie. '
                'Aucun paiement n’est demandé ici.',
              ),
              const SizedBox(height: 20),
              _field('Plaque d’immatriculation', _plate),
              _field('Description précise de la pièce recherchée', _part, lines: 4),
              _field('Nom et prénom', _name),
              _field('Adresse e-mail', _email, keyboard: TextInputType.emailAddress),
              _field('Adresse complète, code postal, pays / territoire', _address, lines: 3),
              _field('Téléphone', _phone, keyboard: TextInputType.phone),
              _field('Numéro WhatsApp', _whatsApp, keyboard: TextInputType.phone, required: false),
              const SizedBox(height: 10),
              FilledButton.icon(
                onPressed: _sendRequest,
                icon: const Icon(Icons.email_outlined),
                label: const Text('Ouvrir l’e-mail de devis'),
              ),
              const SizedBox(height: 12),
              SelectableText('Destinataire : $customerContact',
                  textAlign: TextAlign.center),
              const SizedBox(height: 40),
            ]),
          ),
        ),
      );
}
