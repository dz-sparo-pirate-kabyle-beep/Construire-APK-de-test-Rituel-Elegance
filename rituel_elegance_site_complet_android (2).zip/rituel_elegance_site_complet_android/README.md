# Rituel Élégance — Android, vitrine Shopify complète (prototype)

**Statut : CODE SOURCE uniquement. Pas d'APK/AAB, pas de test sur un appareil, pas de publication Google Play.**

## Ce qui a changé

- **Même design et mêmes collections que le site Shopify** : l'application affiche directement `https://rituel-elegance.fr` via une WebView Android, avec le menu et les pages du site.
- **Tous les produits affichés sur le site**, y compris la collection de livres et guides numériques :
  `https://rituel-elegance.fr/collections/livres-guides-numeriques`.
- **Page officielle de pièces auto** : `https://rituel-elegance.fr/pages/pieces-automobiles-devis` accessible par l'onglet « Devis auto ».
- **Formulaire mobile complémentaire** (« Remplir le devis ») avec plaque, description de la pièce, identité, e-mail, adresse de livraison, téléphone et WhatsApp. Il ouvre **un brouillon d'e-mail** à envoyer manuellement au service client. Il ne prétend pas envoyer automatiquement un formulaire côté Shopify.
- **Icône RE or sur fond noir** (sans la pieuvre), comme demandé.
- Menu de confidentialité et suppression de compte accessible depuis l'application.
- **Pas de jeton d'administration / Storefront API** utilisé dans cette version : la boutique et les catalogues sont chargés du site public.

## Limite importante : achats numériques / paiement

Le prototype **affiche les produits numériques** mais **bloque certaines navigations de paiement Shopify**. Ce garde-fou est une aide au test, PAS une garantie d'absence de tout paiement : le parcours Shopify devra être audité avant d'envoyer une version à Google Play.

Google Play exige généralement **Google Play Billing pour les produits numériques achetables et consommables dans l'application**, sauf exception ou programme régional éligible. Les biens physiques suivent un régime différent. Une WebView avec accès libre au paiement Shopify pour des PDF numériques pourrait enfreindre ce règlement.

À faire avant publication :
1. Déterminer si les PDF sont consultés dans l'application ou uniquement téléchargés/utilisés hors de l'application, et les parcours d'achat/lecture réels.
2. Choisir et implémenter un paiement conforme (Play Billing ou programme / exception applicable), puis tester les paniers mixtes (PDF + produit physique).
3. Retirer l'avertissement « Version de test » uniquement après mise en conformité et tests.
4. Vérifier tous les chemins de checkout (site, scripts Shopify, WebView, onglets, liens externes) ; la protection d'URL de ce prototype n'est pas exhaustive.

Références officielles :
- https://support.google.com/googleplay/android-developer/answer/9858738
- https://support.google.com/googleplay/android-developer/answer/10281818
- https://support.google.com/googleplay/android-developer/answer/9898783

## Construire Android sur un ordinateur

Prérequis : Flutter SDK récent, Android Studio, Java/JDK et Android SDK installés.

```bash
cd rituel_elegance_site_complet_android
flutter create --project-name rituel_elegance --org fr.rituelelegance --platforms android .
python scripts/prepare_android.py --package fr.rituelelegance.boutique
flutter pub get
dart run flutter_launcher_icons
flutter run
```

**Très important :** remplacer `fr.rituelelegance.boutique` par le **nom exact affiché dans Google Play Console** si vous avez déjà choisi un autre identifiant de package. Lors d'une étape précédente la console indiquait 47 caractères ; cela pourrait être différent. Ne créez pas un nouveau package au hasard.

Le script configure `applicationId`, ajoute la permission `INTERNET`, met le label Rituel Élégance et fixe minSdk=24. Il ne prépare PAS la signature de production ni la conformité Play Billing.

Après tous les tests et avec la signature Android configurée :

```bash
flutter build appbundle --release
```

L'AAB se trouvera normalement dans `build/app/outputs/bundle/release/`, à vérifier localement. **NE PAS envoyer le prototype en production tant que les achats, les règles et la sécurité des données n'ont pas été audités.**

## Essais indispensables

- Ouvrir la page d'accueil, les collections, recherche, produit physique, produit numérique, menu, panier.
- Vérifier le téléchargement éventuel des PDF ; le plugin WebView peut nécessiter une prise en charge supplémentaire des téléchargements.
- Ouvrir **Devis auto** puis **Remplir le devis**. Confirmer les informations et envoyer réellement le brouillon avec un client e-mail Android.
- Tester la page officielle sur le site : dans la version HTML inspectable, elle affichait la liste des champs à transmettre, mais nous n'avons pas pu vérifier de formulaire Web fonctionnel. S'il existe un formulaire injecté par JavaScript, vérifier également son affichage et l'envoi réel dans la WebView.
- Si le formulaire du site permet de joindre une pièce/photo, prévoir le sélecteur de fichiers Android (`AndroidWebViewController.setOnShowFileSelector`) et les permissions nécessaires.
- Tester sous différentes connexions, langues, tailles d'écran et versions Android.
- Vérifier le retour Android, les liens externes, la gestion d'une interruption réseau.
- Vérifier la véracité des déclarations « Sécurité des données ». Ce projet utilise une **WebView du site** et peut transmettre des données personnelles via les formulaires, Shopify, cookies et outils d'analyse du site. Les déclarations précédentes prévues pour une app Storefront native ne sont plus fiables.
- Si l'app cible dès 13 ans, vérifier la conformité des formulaires et traitements de données des mineurs, et les éventuels produits soumis à des restrictions d'âge.
- Google peut refuser une application qui est uniquement un miroir de site Web sans valeur ajoutée mobile ; le formulaire natif ajoute une fonction, mais l'approbation n'est pas garantie.

## Autres limites

- Un accès Internet est nécessaire ; le contenu vient du site en direct.
- Le site Shopify peut changer sans prévenir : son menu et ses formulaires doivent être retestés.
- Les fenêtres popup, OAuth, téléchargements et les paiements par fournisseur externe peuvent nécessiter du code Android supplémentaire.
- Les données du formulaire mobile ne sont pas envoyées à un serveur par le code Flutter ; elles sont préremplies dans l'application de messagerie de l'utilisateur. Le message n'est transmis que si l'utilisateur appuie sur Envoyer.
- Le nom et le logo de l'entreprise ne garantissent pas un classement SEO dans Google Play.
